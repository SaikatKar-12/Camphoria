import React from "react";
import { Routes, Route } from "react-router-dom";
import Hero from "./pages/Hero"; 
import Features from "./pages/Features";
import Events from "./pages/Events";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Faq from "./pages/FAQ";
import Contact from "./pages/Contact";
import Testimonial from "./pages/Testimonial";
import Footer from "./pages/Footer";
import NavBar from "./Components/NavBar";

function App() {
  return (
    <>
      <NavBar />

      {/* All Routes */}
      <Routes>
        <Route path="/" element={
          <>
            <section id="home"><Hero /></section>
            <section id="features"><Features /></section>
            <section id="events"><Events /></section>
            <Testimonial />
            <section id="faq"><Faq /></section>
            <section id="contact-us"><Contact /></section>
            <Footer />
          </>
        } />

        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
      </Routes>
    </>
  );
}

export default App;
