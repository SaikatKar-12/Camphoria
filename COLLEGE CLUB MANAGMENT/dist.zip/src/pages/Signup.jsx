import React from 'react'

const Signup = () => {
  return (
    <div>
      Hello
    </div>
  )
}

export default Signup;
